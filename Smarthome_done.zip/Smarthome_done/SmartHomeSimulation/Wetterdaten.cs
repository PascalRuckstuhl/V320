﻿namespace M320_SmartHome {
    public struct Wetterdaten {
        public double Aussentemperatur { get; set; }
        public double Windgeschwindigkeit { get; set; }
        public bool Regen { get; set; }
    }
}
