﻿namespace M320_SmartHome {
    public class BadWC : Zimmer {
        public BadWC() : base("BadWC") {
        }
    }
}
