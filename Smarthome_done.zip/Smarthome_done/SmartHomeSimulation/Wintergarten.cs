﻿namespace M320_SmartHome {
    public class Wintergarten : Zimmer {
        public Wintergarten() : base("Wintergarten") {
        }
    }
}
