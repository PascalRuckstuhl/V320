﻿namespace M320_SmartHome {
    public class Wohnzimmer : Zimmer {
        public Wohnzimmer() : base("Wohnzimmer") {
        }
    }
}
