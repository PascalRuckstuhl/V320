﻿namespace M320_SmartHome {
    public class Schlafzimmer : Zimmer {
        public Schlafzimmer() : base("Schlafen") {
        }
    }
}
